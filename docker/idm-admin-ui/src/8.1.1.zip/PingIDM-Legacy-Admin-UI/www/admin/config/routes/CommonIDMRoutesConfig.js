"use strict";

/*
 * Copyright 2014-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define([], function () {

    var obj = {
        "mandatoryPasswordChangeDialog": {
            base: "landingPage",
            dialog: "org/forgerock/openidm/ui/common/MandatoryPasswordChangeDialog",
            url: "change_password/",
            role: "ui-admin"
        },
        "authenticationUnavailable": {
            view: "org/forgerock/openidm/ui/common/login/AuthenticationUnavailable",
            url: "authenticationUnavailable/"
        },
        "openerHandler": {
            view: "org/forgerock/openidm/ui/common/login/OpenerHandler",
            url: /^openerHandler\/(.*)$/,
            pattern: "openerHandler/?"
        },
        "adminEditSystemObjectView": {
            view: "org/forgerock/openidm/ui/common/resource/EditResourceView",
            role: "ui-admin",
            url: /^resource\/(system)\/(.+)\/(.+)\/edit\/(.+)\/(.+)$/,
            pattern: "resource/?/?/?/edit/?/?",
            forceUpdate: true
        },
        "adminNewSystemObjectView": {
            view: "org/forgerock/openidm/ui/common/resource/EditResourceView",
            role: "ui-admin",
            url: /^resource\/(system)\/(.+)\/(.+)\/add\/$/,
            pattern: "resource/?/?/?/add/"
        },
        "adminListManagedObjectView": {
            view: "org/forgerock/openidm/ui/common/resource/ListResourceView",
            role: "ui-admin",
            url: /^resource\/(managed)\/(.+)\/list\/$/,
            pattern: "resource/?/?/list/"
        },
        "adminEditManagedObjectView": {
            view: "org/forgerock/openidm/ui/common/resource/EditResourceView",
            role: "ui-admin",
            url: /^resource\/(managed)\/(.+)\/edit\/(.+)$/,
            pattern: "resource/?/?/edit/?",
            forceUpdate: true
        },
        "adminNewManagedObjectView": {
            view: "org/forgerock/openidm/ui/common/resource/EditResourceView",
            role: "ui-admin",
            url: /^resource\/(managed)\/(.+)\/add\/$/,
            pattern: "resource/?/?/add/"
        },
        "adminEditRoleEntitlementView": {
            view: "org/forgerock/openidm/ui/common/resource/EditResourceView",
            role: "ui-admin",
            url: /^resource\/(managed)\/(role)\/edit\/(.+)\/(.+)$/,
            pattern: "resource/?/?/edit/?/?",
            forceUpdate: true
        },
        "adminListInternalObjectView": {
            view: "org/forgerock/openidm/ui/common/resource/ListResourceView",
            role: "ui-admin",
            url: /^resource\/(internal)\/(.+)\/list\/$/,
            pattern: "resource/?/?/list/"
        },
        "adminEditInternalObjectView": {
            view: "org/forgerock/openidm/ui/common/resource/EditResourceView",
            role: "ui-admin",
            url: /^resource\/(internal)\/(.+)\/edit\/(.+)$/,
            pattern: "resource/?/?/edit/?",
            forceUpdate: true
        },
        "adminNewInternalObjectView": {
            view: "org/forgerock/openidm/ui/common/resource/EditResourceView",
            role: "ui-admin",
            url: /^resource\/(internal)\/(.+)\/add\/$/,
            pattern: "resource/?/?/add/"
        }
    };

    return obj;
});
