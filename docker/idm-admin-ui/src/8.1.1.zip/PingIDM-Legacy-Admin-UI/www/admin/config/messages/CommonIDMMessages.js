"use strict";

/*
 * Copyright 2011-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define([], function () {

    var obj = {
        "userValidationError": {
            msg: "config.messages.AdminMessages.userValidationError",
            type: "error"
        },
        "resourceValidationError": {
            msg: "config.messages.AdminMessages.resourceValidationError",
            type: "error"
        },
        "socialAuthenticationFailed": {
            msg: "config.messages.AdminMessages.socialAuthenticationFailed",
            type: "error"
        }
    };

    return obj;
});
