"use strict";

/*
 * Copyright 2015-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["underscore", "org/forgerock/commons/ui/common/main/AbstractView"], function (_, AbstractView) {

    var SaveChangesView = AbstractView.extend({
        template: "templates/admin/util/SaveChangesTemplate.html",
        element: "#jqConfirm",
        noBaseTemplate: true,

        render: function render(args, callback) {
            this.element = "#" + args.id;
            this.data.msg = args.msg;
            this.data.changes = args.changes;
            this.data.emptyText = args.empty;

            if (this.data.changes === null) {
                this.data.noGrid = true;
            }

            _.forEach(this.data.changes, _.bind(function (change, i) {
                if (_.isEmpty(change.values)) {
                    this.data.changes[i].empty = true;
                }
            }, this));

            this.parentRender(function () {
                if (callback) {
                    callback();
                }
            });
        }

    });

    return new SaveChangesView();
});
