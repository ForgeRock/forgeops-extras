"use strict";

/*
 * Copyright 2015-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "underscore", "org/forgerock/openidm/ui/admin/util/AdminAbstractView", "org/forgerock/openidm/ui/admin/util/ScriptDialog", "org/forgerock/commons/ui/common/util/UIUtils"], function ($, _, AdminAbstractView, ScriptDialog, UIUtils) {
    var scriptListInstance = {},
        ScriptList = AdminAbstractView.extend({
        template: "templates/admin/util/ScriptList.html",
        noBaseTemplate: true,
        events: {
            "click .addScriptButton": "addScript",
            "click .edit-btn": "editScriptHook",
            "click .script-remove": "removeScript",
            "click .event-hook-empty": "addScriptHook"
        },

        render: function render(args, callback) {
            var tempWorkflow, tempScriptData;

            this.element = args.element;
            this.data = _.cloneDeep(args);

            this.data.eventHooks = {};

            _.forEach(this.data.addedEvents, _.bind(function (event) {
                if (_.has(this.data.currentObject, event)) {
                    tempWorkflow = null;
                    tempScriptData = {};

                    if (this.data.hasWorkflow && this.data.currentObject[event].globals && this.data.currentObject[event].globals.workflowReadable) {
                        tempWorkflow = this.data.currentObject[event].globals.workflowReadable;
                    } else {
                        tempScriptData = this.data.currentObject[event];
                    }

                    this.data.eventHooks[event] = {
                        "workflow": tempWorkflow,
                        "scriptData": tempScriptData
                    };
                }
            }, this));

            this.data.addedEvents = _.sortBy(this.data.addedEvents);

            this.parentRender(function () {
                if (this.data.addedEvents.length) {
                    this.$el.find(".scripts-container").show();
                }

                if (callback) {
                    callback();
                }
            });
        },

        reRender: function reRender() {
            this.render(this.data);

            if (this.$el.find(".scriptSelection option").length === 0) {
                this.$el.find(".scriptSelection").prop('disabled', true);
                this.$el.find(".addScriptButton").prop('disabled', true);
            }

            if (this.data.saveCallback) {
                this.data.saveCallback();
            }
        },

        addScript: function addScript() {
            var selectedEvent = this.$el.find(".scriptSelection").val();

            ScriptDialog.render({
                "element": this.data.element,
                "disableValidation": false,
                "eventName": selectedEvent,
                "scriptData": null,
                "saveCallback": _.bind(function () {
                    this.data.addedEvents.push(selectedEvent);
                    this.data.selectEvents.splice(_.indexOf(this.data.selectEvents, selectedEvent), 1);
                    this.data.currentObject[selectedEvent] = ScriptDialog.generateScript();
                    this.reRender();
                }, this),
                "hasWorkflow": this.data.hasWorkflow,
                "workflowContext": this.data.workflowContext
            });
        },

        removeScript: function removeScript(event) {
            UIUtils.confirmDialog($.t("templates.scriptEditor.deleteMsg"), "danger", _.bind(function () {
                var selectedEvent = this.$el.find(event.currentTarget).closest(".event-hook").attr("data-script-type"),
                    index = _.indexOf(this.data.addedEvents, selectedEvent);

                this.data.addedEvents.splice(index, 1);
                this.data.selectEvents.push(selectedEvent);
                delete this.data.currentObject[selectedEvent];

                if (!this.data.addedEvents.length) {
                    this.$el.find(".scripts-container").hide();
                }

                this.reRender();
            }, this));
        },

        editScriptHook: function editScriptHook(event) {
            var selectedEvent = this.$el.find(event.currentTarget).closest(".event-hook").attr("data-script-type");

            ScriptDialog.render({
                "element": this.data.element,
                "disableValidation": false,
                "eventName": selectedEvent,
                "scriptData": this.data.currentObject[selectedEvent],
                "saveCallback": _.bind(function () {
                    this.data.currentObject[selectedEvent] = ScriptDialog.generateScript();
                    this.reRender();
                }, this),
                "hasWorkflow": this.data.hasWorkflow,
                "workflowContext": this.data.workflowContext
            });
        },

        getScripts: function getScripts() {
            var scripts = _.map(this.data.addedEvents, _.bind(function (event) {
                if (_.has(this.data.currentObject, event)) {
                    return this.data.currentObject[event];
                }
            }, this));

            return _.zipObject(this.data.addedEvents, scripts);
        }
    });

    /* Params:
         element - the element that will receive the scriptList
         label - the label text that shows up above the events/hooks grid
         selectEvents - events to display in the initial dropdown
         addedEvents - events that are already in use
         currentObject - the object containing the current eventHooks
         hasWorkflow - if this instance of the editor supports workflows,
         workflowContext - the context of the workflows if any
         saveCallback - function to be executed after event is edited or deleted
     */

    scriptListInstance.generateScriptList = function (params) {
        var scriptList = {};

        $.extend(true, scriptList, new ScriptList());

        scriptList.render(params);

        return scriptList;
    };

    return scriptListInstance;
});
