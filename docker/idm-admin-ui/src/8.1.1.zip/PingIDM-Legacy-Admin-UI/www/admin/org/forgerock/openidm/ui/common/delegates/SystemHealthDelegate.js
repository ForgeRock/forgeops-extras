"use strict";

/*
 * Copyright 2015-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["org/forgerock/commons/ui/common/util/Constants", "org/forgerock/commons/ui/common/main/AbstractDelegate"], function (Constants, AbstractDelegate) {

    var obj = new AbstractDelegate(Constants.host + Constants.context + "/health");

    obj.connectorDelegateCache = {};

    obj.getOsHealth = function () {
        return obj.serviceCall({
            url: "/os"
        });
    };

    obj.getMemoryHealth = function () {
        return obj.serviceCall({
            url: "/memory"
        });
    };

    obj.getReconHealth = function () {
        return obj.serviceCall({
            url: "/recon"
        });
    };

    return obj;
});
