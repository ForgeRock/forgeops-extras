"use strict";

/*
 * Copyright 2015-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define("org/forgerock/openidm/ui/admin/main", ["org/forgerock/openidm/ui/common/resource/ResourceEditViewRegistry", "./connector/ConnectorRegistry", "./delegates/SiteConfigurationDelegate"]);
