"use strict";

/*
 * Copyright 2011-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["underscore", "org/forgerock/commons/ui/common/main/AbstractView", "org/forgerock/commons/ui/common/util/Constants", "org/forgerock/commons/ui/common/main/AbstractModel", "org/forgerock/openidm/ui/admin/util/WorkflowUtils"], function (_, AbstractView, Constants, AbstractModel) {
    var ProcessModel = AbstractModel.extend({ url: Constants.context + "/workflow/processdefinition" }),
        ProcessDefinitionView = AbstractView.extend({
        template: "templates/admin/workflow/ProcessDefinitionViewTemplate.html",

        events: {},
        render: function render(args, callback) {
            this.model = new ProcessModel();

            this.model.id = args[0];

            this.model.fetch().then(_.bind(function () {

                this.data.processDefinition = this.model.toJSON();

                this.data.diagramUrl = Constants.context + "/workflow/processdefinition/" + this.model.id + "?_fields=/diagram&_mimeType=image/png";

                this.parentRender(_.bind(function () {

                    if (callback) {
                        callback();
                    }
                }, this));
            }, this));
        }
    });

    return new ProcessDefinitionView();
});
