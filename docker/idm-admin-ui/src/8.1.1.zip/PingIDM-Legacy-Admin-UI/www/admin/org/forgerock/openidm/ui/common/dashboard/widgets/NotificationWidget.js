"use strict";

/*
 * Copyright 2017-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "underscore", "org/forgerock/openidm/ui/common/dashboard/widgets/AbstractWidget", "org/forgerock/openidm/ui/common/notifications/NotificationsView"], function ($, _, AbstractWidget, NotificationsView) {
    var widgetInstance = {},
        Widget = AbstractWidget.extend({
        template: "templates/dashboard/widget/NotificationWidgetTemplate.html",
        model: {},

        widgetRender: function widgetRender(args, callback) {
            var notificationsView;

            this.parentRender(_.bind(function () {
                notificationsView = new NotificationsView();
                notificationsView.render({ el: this.$el.find(".notifications-body") });

                if (callback) {
                    callback(this);
                }
            }, this));
        }
    });

    widgetInstance.generateWidget = function (loadingObject, callback) {
        var widget = {};

        $.extend(true, widget, new Widget());

        widget.render(loadingObject, callback);

        return widget;
    };

    return widgetInstance;
});
