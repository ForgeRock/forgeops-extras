"use strict";

/*
 * Copyright 2015-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["lodash", "org/forgerock/openidm/ui/admin/util/AdminAbstractView", "org/forgerock/openidm/ui/common/delegates/ConfigDelegate", "org/forgerock/commons/ui/common/util/Constants", "org/forgerock/commons/ui/common/main/EventManager", "org/forgerock/commons/ui/common/main/ValidatorsManager"], function (_, AdminAbstractView, ConfigDelegate, Constants, EventManager, ValidatorsManager) {

    var SelfServiceView = AdminAbstractView.extend({
        template: "templates/admin/settings/SelfServiceTemplate.html",
        element: "#selfServiceContainer",
        noBaseTemplate: true,
        events: {
            "click #saveSelfServiceURL": "saveSelfServiceURL",
            "keydown": "enterHandler"
        },
        model: {
            uiContextObject: {}
        },
        data: {
            selfServiceURL: ""
        },

        render: function render() {
            var _this = this;

            this.data.docHelpUrl = Constants.DOC_URL;

            ConfigDelegate.readEntity("ui.context/enduser").then(function (data) {
                _this.model.uiContextObject = data;
                _this.data.selfServiceURL = data.urlContextRoot;

                _this.parentRender(function () {
                    ValidatorsManager.bindValidators(_this.$el.find("#systemConfigForm"));
                    ValidatorsManager.validateAllFields(_this.$el.find("#systemConfigForm"));

                    _this.$el.find("#selfServiceURL").focus();
                });
            });
        },

        saveSelfServiceURL: function saveSelfServiceURL(event) {
            event.preventDefault();

            this.model.uiContextObject.urlContextRoot = this.$el.find("#selfServiceURL").val();

            ConfigDelegate.updateEntity("ui.context/enduser", this.model.uiContextObject).then(function () {
                EventManager.sendEvent(Constants.EVENT_DISPLAY_MESSAGE_REQUEST, "selfServiceSaveSuccess");
            });
        },
        enterHandler: function enterHandler(event) {
            if (event.keyCode === Constants.ENTER_KEY) {
                this.$el.find("#saveSelfServiceURL").trigger("click");
            }
        }
    });

    return new SelfServiceView();
});
