"use strict";

/*
 * Copyright 2016-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "underscore", "org/forgerock/commons/ui/common/main/AbstractView", "org/forgerock/commons/ui/common/LoginDialog", "org/forgerock/commons/ui/common/main/Configuration", "org/forgerock/openidm/ui/common/login/ProviderLoginDialog", "org/forgerock/openidm/ui/common/delegates/SocialDelegate"], function ($, _, AbstractView, CommonsLoginDialog, Configuration, ProviderLoginDialog, SocialDelegate) {

    var LoginDialog = AbstractView.extend({
        render: function render(options) {
            SocialDelegate.loginProviders().then(function (configuredProviders) {
                var userNameFlag = Configuration.loggedUser.userNamePasswordLogin;

                if (userNameFlag || configuredProviders.providers.length === 0) {
                    CommonsLoginDialog.render(options);
                } else {
                    ProviderLoginDialog.render(options, Configuration.loggedUser, configuredProviders);
                }
            });
        }
    });
    return new LoginDialog();
});
