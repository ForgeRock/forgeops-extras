"use strict";

/*
 * Copyright 2015-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "lodash", "org/forgerock/commons/ui/common/components/Footer", "org/forgerock/commons/ui/common/main/Configuration", "org/forgerock/openidm/ui/common/delegates/InfoDelegate"], function ($, _, Footer, Configuration, InfoDelegate) {
    function isAdmin() {
        return Configuration.loggedUser && _.has(Configuration.loggedUser, "roles") && _.indexOf(Configuration.loggedUser.uiroles, "ui-admin") > -1;
    }

    var Component = Footer.extend({
        getVersion: function getVersion() {
            return InfoDelegate.getVersion().then(function (data) {
                return data.productVersion + " (" + $.t("openidm.admin.revision") + ": " + data.productRevision + ")";
            });
        },
        showVersion: function showVersion() {
            return isAdmin();
        }
    });

    return new Component();
});
