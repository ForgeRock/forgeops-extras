"use strict";

/*
 * Copyright 2015-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["underscore", "org/forgerock/commons/ui/common/util/Constants", "org/forgerock/commons/ui/common/main/AbstractDelegate"], function (_, Constants, AbstractDelegate) {

    var obj = new AbstractDelegate(Constants.host + Constants.context + "/script");

    obj.evalScript = function (script, additionalGlobals) {
        var scriptDetails = _.cloneDeep(script);

        if (_.isUndefined(scriptDetails.globals) || _.isNull(scriptDetails.globals)) {
            scriptDetails.globals = {};
        }

        if (additionalGlobals) {
            scriptDetails.globals = _.assignIn(scriptDetails.globals, additionalGlobals);
        }

        return obj.serviceCall({
            url: "?_action=eval",
            type: "POST",
            data: JSON.stringify(scriptDetails, function (_k, v) {
                return v === undefined ? null : v;
            }),
            errorsHandlers: {
                "error": {
                    status: "500"
                }
            }
        });
    };

    obj.evalLinkQualifierScript = function (script) {
        script.globals = script.globals || {};
        script.globals.returnAll = true;

        return obj.evalScript(script);
    };

    obj.parseQueryFilter = function (filterString) {
        return obj.evalScript({
            "type": "text/javascript",
            "source": "org.forgerock.json.resource.QueryFilters.parse(queryFilter).accept(new org.forgerock.util.query.MapFilterVisitor(), null);",
            "globals": {
                "queryFilter": filterString
            }
        });
    };

    return obj;
});
