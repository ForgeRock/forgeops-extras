"use strict";

/*
 * Copyright 2015-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["underscore", "org/forgerock/commons/ui/common/main/AbstractConfigurationAware", "org/forgerock/commons/ui/common/util/ModuleLoader"], function (_, AbstractConfigurationAware, ModuleLoader) {
    var obj = new AbstractConfigurationAware();

    obj.updateConfigurationCallback = function (conf) {
        this.configuration = conf;

        _.forEach(conf, function (val, key) {
            require.config({
                "map": {
                    "*": { key: val }
                }
            });
        });
    };

    obj.getEditViewModule = function (resource) {
        if (_.isUndefined(this.configuration["resource-" + resource])) {
            return ModuleLoader.load("org/forgerock/openidm/ui/common/resource/GenericEditResourceView");
        } else {
            return ModuleLoader.load(this.configuration["resource-" + resource]);
        }
    };

    return obj;
});
