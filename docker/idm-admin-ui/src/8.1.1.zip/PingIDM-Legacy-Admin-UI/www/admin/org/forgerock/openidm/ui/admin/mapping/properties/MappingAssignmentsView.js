"use strict";

/*
 * Copyright 2015-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "underscore", "org/forgerock/openidm/ui/admin/mapping/util/MappingAdminAbstractView", "org/forgerock/openidm/ui/admin/mapping/util/MappingUtils"], function ($, _, MappingAdminAbstractView, mappingUtils) {

    var MappingAssignmentsView = MappingAdminAbstractView.extend({
        template: "templates/admin/mapping/properties/MappingAssignmentsViewTemplate.html",
        element: "#mappingAssignments",
        noBaseTemplate: true,
        events: {},
        model: {},
        data: {},

        render: function render(args, callback) {
            this.model.mappingName = this.getMappingName();
            this.model.mapping = this.getCurrentMapping();

            mappingUtils.getAllAssignments(this.model.mappingName).then(_.bind(function (assignments) {

                this.data.assignments = assignments;

                this.parentRender(_.bind(function () {
                    if (this.data.assignments.length > 0) {
                        //Needs to be above the view scope to open the parent panel
                        $("a[href='#assignmentsBody']").collapse("show");
                        $("#assignmentsBody").toggleClass("in", true);
                    }

                    if (callback) {
                        callback();
                    }
                }, this));
            }, this));
        }
    });

    return new MappingAssignmentsView();
});
