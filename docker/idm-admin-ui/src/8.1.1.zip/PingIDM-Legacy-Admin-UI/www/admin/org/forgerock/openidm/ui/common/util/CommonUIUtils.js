"use strict";

/*
 * Copyright 2018-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["lodash"], function (_) {
    var obj = {};

    /**
     * Traverse object of unknown complexity and replace any 'empty string' with 'null'
     * @param {object} data
     * @returns {object} identical to data object with all 'empty string' converted to 'null'
     */
    obj.replaceEmptyStringWithNull = function (data) {
        var searchForEmptyString,
            traverseObject = function traverseObject(obj) {
            return _.forOwn(obj, function (value, key) {
                obj[key] = searchForEmptyString(value);
            });
        };

        searchForEmptyString = function searchForEmptyString(value) {
            if (!_.isString(value)) {
                if (_.isObject(value)) {
                    return traverseObject(value);
                } else {
                    return value;
                }
            } else if (value === '') {
                return null;
            } else {
                return value;
            }
        };

        return searchForEmptyString(data);
    };

    return obj;
});
