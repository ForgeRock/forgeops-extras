"use strict";

/*
 * Copyright 2011-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["org/forgerock/commons/ui/common/util/Constants", "org/forgerock/commons/ui/common/main/AbstractDelegate"], function (Constants, AbstractDelegate) {

    var obj = new AbstractDelegate(Constants.host + Constants.context + "/internal/user");

    obj.patchSelectedUserAttributes = function (id, rev, patchDefinitionObject, successCallback, errorCallback, noChangesCallback) {
        //PATCH for repo is unsupported

        return obj.readEntity(id).then(function (user) {
            var i, v;

            for (i = 0; i < patchDefinitionObject.length; i++) {
                v = patchDefinitionObject[i];

                // replace any leading slashes to translate basic JSON Pointer
                // back into regular JS object property references
                v.field = v.field.replace(/^\//, '');

                user[v.field] = v.value;
            }

            return obj.updateEntity(id, user, successCallback, errorCallback);
        });
    };

    return obj;
});
