"use strict";

/*
 * Copyright 2011-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["org/forgerock/commons/ui/common/util/Constants", "org/forgerock/commons/ui/common/main/AbstractDelegate", "org/forgerock/commons/ui/common/main/Configuration", "org/forgerock/commons/ui/common/main/EventManager"], function (Constants, AbstractDelegate, configuration, eventManager) {

    var obj = new AbstractDelegate(Constants.host + Constants.context + "/endpoint/usernotifications");

    obj.getNotificationsForUser = function (successCallback, errorCallback) {
        obj.serviceCall({
            url: "",
            success: function success(data) {
                if (successCallback) {
                    successCallback(data);
                }
            },
            error: errorCallback
        });
    };

    obj.deleteEntity = function (id, successCallback, errorCallback) {
        var callParams = { url: "/" + id, type: "DELETE", success: successCallback, error: errorCallback };
        this.serviceCall(callParams);
    };

    return obj;
});
