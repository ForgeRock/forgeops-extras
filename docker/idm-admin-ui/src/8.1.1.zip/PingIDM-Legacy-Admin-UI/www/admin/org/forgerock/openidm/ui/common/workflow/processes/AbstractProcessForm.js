"use strict";

/*
 * Copyright 2011-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["underscore", "org/forgerock/commons/ui/common/main/AbstractView", "org/forgerock/commons/ui/common/main/ValidatorsManager", "org/forgerock/commons/ui/common/main/EventManager", "org/forgerock/commons/ui/common/util/Constants", "org/forgerock/openidm/ui/common/workflow/WorkflowDelegate", "org/forgerock/commons/ui/common/main/Configuration"], function (_, AbstractView, validatorsManager, eventManager, constants, workflowManager, conf) {
    var AbstractProcessForm = AbstractView.extend({
        template: "templates/common/EmptyTemplate.html",
        element: "#processContent",

        events: {
            "onValidate": "onValidate"
        },

        postRender: function postRender(callback) {
            if (callback) {
                callback();
            }
        },

        prepareData: function prepareData(callback) {
            callback();
        },

        render: function render(processDefinition, category, args, callback) {
            this.setElement(this.element);
            this.$el.unbind();
            this.delegateEvents();
            this.processDefinition = processDefinition;
            this.category = category;
            this.args = args;

            this.prepareData(_.bind(function () {
                this.parentRender(function () {
                    this.postRender(callback);
                    this.reloadData();
                });
            }, this));
        },

        reloadData: function reloadData() {}

    });

    return AbstractProcessForm;
});
