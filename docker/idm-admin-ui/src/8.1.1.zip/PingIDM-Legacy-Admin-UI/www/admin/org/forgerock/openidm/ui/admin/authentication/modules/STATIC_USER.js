"use strict";

/*
 * Copyright 2016-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "lodash", "form2js", "org/forgerock/openidm/ui/admin/authentication/AuthenticationAbstractView"], function ($, _, Form2js, AuthenticationAbstractView) {

    var StaticUserView = AuthenticationAbstractView.extend({
        template: "templates/admin/authentication/modules/STATIC_USER.html",

        knownProperties: AuthenticationAbstractView.prototype.knownProperties.concat(["username", "password"]),

        render: function render(args, callback) {
            var _this = this;

            this.data = _.cloneDeep(args);
            this.data.resources = ["internal/user"]; // STATIC and INTERNAL modules only have the single option.
            this.data.customProperties = this.getCustomPropertiesList(this.knownProperties, this.data.config.properties || {});

            this.parentRender(function () {
                callback();
                _this.postRenderComponents({
                    "customProperties": _this.data.customProperties,
                    "name": _this.data.config.name,
                    "augmentSecurityContext": _this.data.config.properties.augmentSecurityContext || {}
                });
            });
        }
    });

    return new StaticUserView();
});
