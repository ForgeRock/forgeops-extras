"use strict";

/*
 * Copyright 2016-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["lodash", "org/forgerock/commons/ui/common/main/AbstractModel", "org/forgerock/openidm/ui/common/util/BackgridUtils", "org/forgerock/commons/ui/common/main/AbstractCollection"], function (_, AbstractModel, BackgridUtils, AbstractCollection) {
    var SchedulerCollection = AbstractCollection.extend({
        initialize: function initialize(models, options) {
            this.url = options.url;
            this.model = AbstractModel.extend({ "url": options.url });
            this.state = _.assignIn({}, this.state, options.state);
            this.queryParams = _.assignIn({}, this.queryParams, BackgridUtils.getQueryParams({
                _queryFilter: options._queryFilter
            }));
        }
    });
    return SchedulerCollection;
});
