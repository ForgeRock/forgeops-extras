"use strict";

/*
 * Copyright 2014-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["underscore", "org/forgerock/openidm/ui/admin/mapping/util/MappingAdminAbstractView", "org/forgerock/openidm/ui/admin/mapping/scheduling/SchedulerView"], function (_, MappingAdminAbstractView, SchedulerView) {

    var ScheduleView = MappingAdminAbstractView.extend({
        template: "templates/admin/mapping/ScheduleTemplate.html",
        element: "#mappingContent",
        noBaseTemplate: true,

        render: function render(args, callback) {
            this.parentRender(_.bind(function () {
                SchedulerView.render();

                if (callback) {
                    callback();
                }
            }, this));
        }
    });

    return new ScheduleView();
});
