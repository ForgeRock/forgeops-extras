"use strict";

/*
 * Copyright 2020-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "lodash", "org/forgerock/openidm/ui/admin/connector/ConnectorTypeAbstractView"], function ($, _, ConnectorTypeAbstractView) {

    var WorkdayView = ConnectorTypeAbstractView.extend({
        events: {
            "click #includeOrganizations": "toggleExcludes"
        },
        toggleExcludes: function toggleExcludes() {
            if (this.$el.find("#includeOrganizations").is(":checked")) {
                this.$el.find(".excludes-boolean-fields").show();
            } else {
                this.$el.find(".excludes-boolean-fields").hide();
            }
        },
        render: function render(args, callback) {
            var _this = this;

            var callbackOverride = function callbackOverride() {
                _this.toggleExcludes();

                if (callback) {
                    callback();
                }
            };

            ConnectorTypeAbstractView.prototype.render.call(this, args, callbackOverride);
        }
    });

    return new WorkdayView();
});
