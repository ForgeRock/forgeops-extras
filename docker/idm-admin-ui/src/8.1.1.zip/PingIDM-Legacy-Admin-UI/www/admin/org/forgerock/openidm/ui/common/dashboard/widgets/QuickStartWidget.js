"use strict";

/*
 * Copyright 2015-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "handlebars", "underscore", "backbone", "org/forgerock/openidm/ui/common/dashboard/widgets/AbstractWidget", "org/forgerock/commons/ui/common/main/EventManager", "backgrid", "org/forgerock/commons/ui/common/util/BackgridUtils"], function ($, handlebars, _, Backbone, AbstractWidget, eventManager, Backgrid, BackgridUtils) {
    var widgetInstance = {},
        Widget = AbstractWidget.extend({
        template: "templates/dashboard/widget/QuickStartWidgetTemplate.html",
        model: {
            "overrideTemplate": "dashboard/widget/_quickStartConfig",
            "editedQuickCard": null
        },
        widgetRender: function widgetRender(args, callback) {
            this.data.cards = args.widget.cards;

            this.partials.push("partials/dashboard/widget/_quickStartConfig.html");

            _.forEach(this.data.cards, _.bind(function (card) {
                card.name = $.t(card.name);

                if (card.event) {
                    this.events["click #" + card.uid] = function (e) {
                        e.preventDefault();
                        eventManager.sendEvent(card.event);
                    };
                }
            }, this));

            this.events["click .widget-body a"] = function (e) {
                e.preventDefault();
                var parent = $(event.target).parents('.card'),
                    index = this.$el.find(".card").index(parent),
                    href = handlebars.Utils.escapeExpression(this.data.cards[index].href);

                window.location.href = window.location.protocol + "//" + window.location.host + window.location.pathname + href;
            };

            this.parentRender(_.bind(function () {
                if (callback) {
                    callback(this);
                }
            }, this));
        },
        customSettingsSave: function customSettingsSave(dialogRef, widget) {
            widget.cards = [];

            _.forEach(this.model.QuickObjectCollection.models, function (model) {
                widget.cards.push({
                    "name": model.attributes.name,
                    "icon": model.attributes.icon,
                    "href": handlebars.escapeExpression(model.attributes.href)
                });
            });

            widget.size = dialogRef.$modalBody.find("#widgetSize").val();

            return widget;
        },
        customSettingsLoad: function customSettingsLoad(dialogRef) {
            var _this = this;

            this.model.QuickStartModel = Backbone.Model.extend({});
            this.model.QuickStartObjects = Backbone.Collection.extend({ model: this.model.QuickStartModel });
            this.model.QuickObjectCollection = new this.model.QuickStartObjects();

            _.forEach(this.data.cards, _.bind(function (card) {
                this.model.QuickObjectCollection.add(card);
            }, this));

            this.model.quickObjectGrid = new Backgrid.Grid({
                className: "table backgrid",
                emptyText: $.t("dashboard.quickStart.noQuickStartLinks"),
                columns: BackgridUtils.addSmallScreenCell([{
                    name: "name",
                    cell: "string",
                    sortable: false,
                    editable: false
                }, {
                    name: "",
                    cell: BackgridUtils.ButtonCell([{
                        className: "fa fa-times grid-icon pull-right",
                        callback: function callback() {
                            this.model.destroy();
                        }
                    }, {
                        className: "fa fa-pencil grid-icon pull-right",
                        callback: function callback() {
                            _this.model.editedQuickCard = this.model;
                            _this.model.editedElement = this.el;

                            _this.clearQuickLinkForm(dialogRef);

                            dialogRef.$modalBody.find("#quickLinkName").val(this.model.attributes.name);
                            dialogRef.$modalBody.find("#quickLinkHref").val(this.model.attributes.href);
                            dialogRef.$modalBody.find("#quickLinkIcon").val(this.model.attributes.icon);

                            dialogRef.$modalBody.find(".fr-edit-well-header").html($.t("dashboard.quickStart.updateQuicklink"));
                            dialogRef.$modalBody.find("#createQuickLink").html("Update");

                            dialogRef.$modalBody.find(".iconpicker-container .input-group-addon i").attr("class", "fa " + this.model.attributes.icon);

                            dialogRef.$modalBody.find("#addQuickLink").hide();
                            dialogRef.$modalBody.find("#quickLinkAddHolder").show();
                        }
                    }]),
                    sortable: false,
                    editable: false
                }]),
                collection: this.model.QuickObjectCollection
            });

            dialogRef.$modalBody.find("#addQuickLink").bind("click", function () {
                dialogRef.$modalBody.find(".fr-edit-well-header").html($.t("dashboard.quickStart.addQuicklink"));
                dialogRef.$modalBody.find("#createQuickLink").html("Add");

                dialogRef.$modalBody.find("#addQuickLink").hide();
                dialogRef.$modalBody.find("#quickLinkAddHolder").show();
            });

            dialogRef.$modalBody.find("#cancelQuickLink").bind("click", function () {
                _this.clearQuickLinkForm(dialogRef);

                _this.model.editedQuickCard = null;
                _this.model.editedElement = null;

                dialogRef.$modalBody.find("#addQuickLink").show();
                dialogRef.$modalBody.find("#quickLinkAddHolder").hide();
            });

            dialogRef.$modalBody.find("#createQuickLink").bind("click", function () {
                if (!_.isNull(_this.model.editedQuickCard)) {
                    _this.model.editedQuickCard.attributes.name = handlebars.Utils.escapeExpression(dialogRef.$modalBody.find("#quickLinkName").val());
                    _this.model.editedQuickCard.attributes.href = handlebars.Utils.escapeExpression(dialogRef.$modalBody.find("#quickLinkHref").val());
                    _this.model.editedQuickCard.attributes.icon = handlebars.Utils.escapeExpression(dialogRef.$modalBody.find("#quickLinkIcon").val());

                    _this.clearQuickLinkForm(dialogRef);

                    dialogRef.$modalBody.find("#addQuickLink").show();
                    dialogRef.$modalBody.find("#quickLinkAddHolder").hide();

                    _this.model.editedQuickCard = null;
                    _this.model.editedElement = null;
                } else {
                    _this.model.QuickObjectCollection.add({
                        "name": handlebars.Utils.escapeExpression(dialogRef.$modalBody.find("#quickLinkName").val()),
                        "href": handlebars.Utils.escapeExpression(dialogRef.$modalBody.find("#quickLinkHref").val()),
                        "icon": handlebars.Utils.escapeExpression(dialogRef.$modalBody.find("#quickLinkIcon").val())
                    });
                }

                dialogRef.$modalBody.find("#addQuickLink").show();
                dialogRef.$modalBody.find("#quickLinkAddHolder").hide();

                _this.model.quickObjectGrid.render();
                _this.clearQuickLinkForm(dialogRef);
            });

            dialogRef.$modalBody.find("#quickStartGridHolder").append(this.model.quickObjectGrid.render().el);
        },

        clearQuickLinkForm: function clearQuickLinkForm(dialogRef) {
            dialogRef.$modalBody.find("#quickLinkName").val("");
            dialogRef.$modalBody.find("#quickLinkHref").val("");
            dialogRef.$modalBody.find("#quickLinkIcon").val("");
            dialogRef.$modalBody.find(".iconpicker-container .input-group-addon i").attr("class", "");
        }
    });

    widgetInstance.generateWidget = function (loadingObject, callback) {
        var widget = {};

        $.extend(true, widget, new Widget());

        widget.render(loadingObject, callback);

        return widget;
    };

    return widgetInstance;
});
