"use strict";

/*
 * Copyright 2016-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "lodash", "form2js", "org/forgerock/openidm/ui/admin/authentication/AuthenticationAbstractView"], function ($, _, Form2js, AuthenticationAbstractView) {

    var IWAView = AuthenticationAbstractView.extend({
        template: "templates/admin/authentication/modules/IWA.html",

        knownProperties: AuthenticationAbstractView.prototype.knownProperties.concat(["servicePrincipal", "keytabFileName", "kerberosRealm", "kerberosServerName", "groupComparisonMethod"]),

        render: function render(args, callback) {
            var _this = this;

            this.data = _.cloneDeep(args);
            this.data.userOrGroupValue = "userRoles";
            this.data.userOrGroupOptions = _.cloneDeep(AuthenticationAbstractView.prototype.userOrGroupOptions);
            this.data.customProperties = this.getCustomPropertiesList(this.knownProperties, this.data.config.properties || {});
            this.data.userOrGroupDefault = this.getUserOrGroupDefault(this.data.config || {});

            this.parentRender(function () {
                callback();

                _this.postRenderComponents({
                    "customProperties": _this.data.customProperties,
                    "name": _this.data.config.name,
                    "augmentSecurityContext": _this.data.config.properties.augmentSecurityContext || {},
                    "userOrGroup": _this.data.userOrGroupDefault
                });
            });
        }
    });

    return new IWAView();
});
