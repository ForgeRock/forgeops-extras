"use strict";

/*
 * Copyright 2014-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["underscore", "org/forgerock/commons/ui/common/main/AbstractConfigurationAware", "org/forgerock/commons/ui/common/util/ModuleLoader"], function (_, AbstractConfigurationAware, ModuleLoader) {
    var obj = new AbstractConfigurationAware();

    obj.updateConfigurationCallback = function (conf) {
        this.configuration = conf;

        _.forEach(conf, function (val) {
            require.config({
                "map": {
                    "*": { key: val }
                }
            });
        });
    };

    obj.getConnectorModule = function (type) {
        if (_.isUndefined(this.configuration[type])) {
            return ModuleLoader.load("org/forgerock/openidm/ui/admin/connector/ConnectorTypeView");
        } else {
            return ModuleLoader.load(this.configuration[type]);
        }
    };

    return obj;
});
