"use strict";

/*
 * Copyright 2011-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "underscore", "org/forgerock/openidm/ui/common/workflow/processes/AbstractProcessForm", "UserDelegate", "org/forgerock/commons/ui/common/main/Configuration", "org/forgerock/commons/ui/common/main/ValidatorsManager"], function ($, _, AbstractProcessForm, userDelegate, conf, validatorsManager) {
    var SendNotificationProcess = AbstractProcessForm.extend({

        template: "templates/workflow/processes/customview/SendNotificationTemplate.html",

        prepareData: function prepareData(callback) {
            var nTypes, notificationType;
            _.assignIn(this.data, this.processDefinition);
            this.data.loggedUser = conf.loggedUser.toJSON();

            nTypes = {};
            for (notificationType in conf.globalData.notificationTypes) {
                nTypes[notificationType] = $.t(conf.globalData.notificationTypes[notificationType].name);
            }
            this.data.notificationTypes = nTypes;
            this.data.defaultNotificationType = conf.globalData.notificationTypes.defaultType;

            _.bind(function () {

                userDelegate.getAllUsers(_.bind(function (users) {

                    var resultMap = {},
                        userPointer,
                        user;
                    for (userPointer in users) {
                        user = users[userPointer];
                        resultMap[user._id] = user.givenName + " " + user.familyName;
                    }
                    this.data.users = resultMap;
                    callback();
                }, this));
            }, this)();
        },

        postRender: function postRender() {
            validatorsManager.bindValidators(this.$el);
            validatorsManager.validateAllFields(this.$el);
        }

    });

    return new SendNotificationProcess();
});
