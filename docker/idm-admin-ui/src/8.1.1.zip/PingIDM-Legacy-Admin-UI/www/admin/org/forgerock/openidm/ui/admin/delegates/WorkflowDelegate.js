"use strict";

/*
 * Copyright 2015-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["org/forgerock/commons/ui/common/util/Constants", "org/forgerock/commons/ui/common/main/AbstractDelegate"], function (Constants, AbstractDelegate) {

    var obj = new AbstractDelegate(Constants.host + Constants.context + "/workflow/processdefinition");

    obj.availableWorkflows = function () {
        var errorHandlers = {
            "notFound": {
                status: "404"
            },
            "internalError": {
                status: "500"
            }
        };

        return obj.serviceCall({
            url: "?_queryFilter=true&_fields=_id",
            type: "GET",
            errorsHandlers: errorHandlers
        });
    };

    obj.workflowFormProperties = function (id) {
        var errorHandlers = {
            "notFound": {
                status: "404"
            }
        };

        return obj.serviceCall({
            url: "/" + id,
            type: "GET",
            errorsHandlers: errorHandlers
        });
    };

    return obj;
});
