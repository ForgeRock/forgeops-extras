"use strict";

/*
 * Copyright 2011-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["org/forgerock/commons/ui/common/main/AbstractView", "org/forgerock/openidm/ui/common/resource/ResourceEditViewRegistry"], function (AbstractView, ResourceEditViewRegistry) {
    var EditResourceView = AbstractView.extend({
        events: {},
        render: function render(args, callback) {
            var view,
                resource = args[1];

            if (args[0] === "system") {
                resource += "/" + args[2];
            }

            ResourceEditViewRegistry.getEditViewModule(resource).then(function (view) {
                view.render(args, callback);
            });
        }
    });

    return new EditResourceView();
});
