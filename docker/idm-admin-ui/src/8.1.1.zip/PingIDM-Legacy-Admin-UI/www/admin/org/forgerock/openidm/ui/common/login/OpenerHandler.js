"use strict";

/*
 * Copyright 2016-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "lodash", "handlebars", "org/forgerock/commons/ui/common/main/Router"], function ($, _, Handlebars, Router) {

    var OpenerLoginView = function OpenerLoginView() {},
        obj;

    obj = new OpenerLoginView();

    obj.render = function (args) {
        var params = Router.convertCurrentUrlToJSON().params,
            moduleName,
            type = args[0];

        if (_.includes(type, "bind/")) {
            type = "bind";
        }

        switch (type) {
            case "loginDialog":
                moduleName = "org/forgerock/openidm/ui/common/login/ProviderLoginDialog";
                break;
            case "bind":
                moduleName = "org/forgerock/openidm/ui/user/profile/SocialIdentitiesTab";
                break;
            default:
                moduleName = null;
                window.location = "#noOpenerFound";
                break;
        }

        if (!_.isNull(moduleName)) {
            opener.require([moduleName], function (module) {
                module.oauthReturn(params);

                window.close();
            });
        }

        return;
    };

    return obj;
});
