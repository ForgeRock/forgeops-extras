"use strict";

/*
 * Copyright 2015-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "underscore", "org/forgerock/openidm/ui/admin/util/AdminAbstractView", "org/forgerock/openidm/ui/admin/assignment/AddAssignmentView", "org/forgerock/openidm/ui/admin/assignment/EditAssignmentView"], function ($, _, AdminAbstractView, AddAssignmentView, EditAssignmentView) {
    var AssignmentView = AdminAbstractView.extend({
        template: "templates/common/EmptyTemplate.html",

        render: function render(args, callback) {
            this.parentRender(_.bind(function () {
                this.$el.append('<div id="assignmentHolder"></div>');

                if (args.length === 2) {
                    AddAssignmentView.render(args);
                } else {
                    EditAssignmentView.render(args);
                }

                if (callback) {
                    callback();
                }
            }, this));
        }
    });

    return new AssignmentView();
});
