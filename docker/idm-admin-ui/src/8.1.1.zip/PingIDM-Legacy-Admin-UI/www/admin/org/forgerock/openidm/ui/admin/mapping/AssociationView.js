"use strict";

/*
 * Copyright 2015-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["underscore", "org/forgerock/openidm/ui/admin/mapping/util/MappingAdminAbstractView", "org/forgerock/openidm/ui/admin/mapping/association/DataAssociationManagementView", "org/forgerock/openidm/ui/admin/mapping/association/IndividualRecordValidationView", "org/forgerock/openidm/ui/admin/mapping/association/ReconciliationQueryFiltersView", "org/forgerock/openidm/ui/admin/mapping/association/AssociationRuleView"], function (_, MappingAdminAbstractView, DataAssociationManagementView, IndividualRecordValidationView, ReconciliationQueryFiltersView, AssociationRuleView) {

    var AssociationView = MappingAdminAbstractView.extend({
        template: "templates/admin/mapping/AssociationTemplate.html",
        element: "#mappingContent",
        noBaseTemplate: true,

        render: function render(args, callback) {
            var mapping = this.getCurrentMapping();

            this.data.hideObjectFilters = true;
            _.forEach(IndividualRecordValidationView.model.scripts, _.bind(function (script) {
                if (_.has(IndividualRecordValidationView.model, "mapping")) {
                    if (_.has(IndividualRecordValidationView.model.mapping, script)) {
                        this.data.hideObjectFilters = false;
                    }
                } else if (_.has(mapping, script)) {
                    this.data.hideObjectFilters = false;
                }
            }, this));

            this.data.hideReconQueries = !mapping.sourceQuery && !mapping.targetQuery;

            this.parentRender(_.bind(function () {
                DataAssociationManagementView.render();
                ReconciliationQueryFiltersView.render();
                IndividualRecordValidationView.render();
                AssociationRuleView.render({});

                if (callback) {
                    callback();
                }
            }, this));
        }
    });

    return new AssociationView();
});
