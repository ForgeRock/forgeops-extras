"use strict";

/*
 * Copyright 2017-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "lodash", "bootstrap-dialog", "org/forgerock/commons/ui/common/util/Constants"], function ($, _, BootstrapDialog, Constants) {
    var obj = {};
    /**
     * @param args - non-default JSON object for bootstapDialog
     *
     * default config includes:
     *        type: BootstrapDialog.TYPE_DEFAULT,
     *        size: BootstrapDialog.SIZE_WIDE,
     *        closable: true,
     *        closeByBackdrop: false,
     *        closeByKeyboard: false
     * which can be overwritten by passing a new value in the 'args' object
     *
     * The 'button' array accepts both "cancel" and "close" for default implimentations
     */
    obj.createModal = function (args) {
        var dialogDefaults = {
            type: BootstrapDialog.TYPE_DEFAULT,
            size: BootstrapDialog.SIZE_WIDE,
            closable: true,
            closeByBackdrop: false,
            closeByKeyboard: false
        },
            commonButtons = {
            "cancel": {
                label: $.t("common.form.cancel"),
                action: function action(dialogRef) {
                    dialogRef.close();
                }
            },
            "close": {
                label: $.t("common.form.close"),
                action: function action(dialogRef) {
                    dialogRef.close();
                }
            }
        },
            dialogCustomSettings = {};

        if (args) {
            dialogCustomSettings = _.assignIn(dialogDefaults, args);
        }

        if (args.buttons && args.buttons.length) {
            dialogCustomSettings.buttons = _.map(args.buttons, function (button) {
                if (_.isString(button)) {
                    button = commonButtons[button];
                } else if (_.isUndefined(button.hotkey) && button.label === $.t("common.form.save")) {
                    button.hotkey = Constants.ENTER_KEY;
                }
                return button;
            });
        }

        return new BootstrapDialog(dialogCustomSettings);
    };

    return obj;
});
