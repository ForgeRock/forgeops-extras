"use strict";

/*
 * Copyright 2017-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "org/forgerock/commons/ui/common/util/Constants", "org/forgerock/commons/ui/common/main/AbstractDelegate"], function ($, Constants, AbstractDelegate) {

    var obj = new AbstractDelegate(Constants.host + Constants.context + "/");

    obj.getRoles = function () {
        return obj.serviceCall({
            url: "managed/role?_queryFilter=true",
            type: "GET"
        });
    };

    obj.getActiveUsers = function () {
        return obj.serviceCall({
            url: 'report/managed/user?_queryFilter=/accountStatus+eq+"active"&aggregateFields=VALUE=/accountStatus',
            type: "GET"
        });
    };

    obj.getManualRegistrations = function () {
        return obj.serviceCall({
            url: 'report/managed/user?_queryFilter=/accountStatus+eq+"active"&aggregateFields=VALUE=/idps',
            type: "GET"
        });
    };
    return obj;
});
