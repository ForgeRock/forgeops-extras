"use strict";

/*
 * Copyright 2015-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "underscore", "dimple", "org/forgerock/openidm/ui/common/dashboard/widgets/AbstractWidget", "org/forgerock/openidm/ui/common/delegates/SystemHealthDelegate"], function ($, _, dimple, AbstractWidget, SystemHealthDelegate) {
    var widgetInstance = {},
        Widget = AbstractWidget.extend({
        template: "templates/dashboard/widget/DashboardSingleWidgetTemplate.html",
        model: {
            reconChart: null,
            uniqueCount: 0,
            chartData: [],
            chartX: 20,
            chartY: 20,
            chartWidth: 480,
            chartHeight: 355,
            drawTime: 1000,
            canvasWidth: "100%",
            canvasHeight: 390,
            refreshSpeed: 5000
        },
        widgetRender: function widgetRender(args, callback) {
            var areaSeries, svg;

            this.parentRender(_.bind(function () {
                this.model.currentData = [];

                this.$el.find(".dashboard-loading-message").show();

                svg = dimple.newSvg(this.$el[0], "100%", 390);

                this.model.reconChart = new dimple.chart(svg, []);
                this.model.reconChart.setBounds(this.model.chartX, this.model.chartY, this.model.chartWidth, this.model.chartHeight);

                this.model.x = this.model.reconChart.addCategoryAxis("x", "id");
                this.model.x.hidden = true;
                this.model.y = this.model.reconChart.addMeasureAxis("y", "activeThreads");

                areaSeries = this.model.reconChart.addSeries(null, dimple.plot.area);

                areaSeries.getTooltipText = _.bind(function (e) {
                    var data = this.model.chartData[e.x];

                    return ["Timestamp: " + data.timestamp, "Active Recons : " + data.activeThreads];
                }, this);

                this.model.reconChart.draw();

                this.reconUsagePolling();

                window.onresize = _.bind(function () {
                    if (this.model.reconChart) {
                        this.model.reconChart.draw(0, true);
                    }
                }, this);

                if (callback) {
                    callback(this);
                }
            }, this));
        },

        reconUsagePolling: function reconUsagePolling() {
            var date;

            SystemHealthDelegate.getReconHealth().then(_.bind(function (widgetData) {
                date = new Date(Date.now());
                widgetData.timestamp = date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();

                widgetData.id = this.model.uniqueCount;

                this.model.uniqueCount++;

                this.model.chartData.push(widgetData);

                this.model.reconChart.data = _.clone(this.model.chartData);

                if (this.model.reconChart.data.length > 1) {
                    this.$el.find(".dashboard-loading-message").hide();

                    this.model.y.overrideMin = 0;
                    this.model.y.overrideMax = widgetData.maximumPoolSize;

                    this.model.reconChart.draw(this.model.drawTime);
                }

                if (window.location.hash === "#dashboard/" || window.location.hash === "") {
                    this.model.pollTimer = _.delay(_.bind(function () {
                        this.reconUsagePolling();
                    }, this), this.model.refreshSpeed);
                }
            }, this));
        }
    });

    widgetInstance.generateWidget = function (loadingObject, callback) {
        var widget = {};

        $.extend(true, widget, new Widget());

        widget.render(loadingObject, callback);

        return widget;
    };

    return widgetInstance;
});
