"use strict";

/*
 * Copyright 2014-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "underscore", "handlebars", "org/forgerock/openidm/ui/common/delegates/ConfigDelegate", "org/forgerock/commons/ui/common/util/Constants", "org/forgerock/commons/ui/common/main/EventManager", "org/forgerock/openidm/ui/admin/mapping/util/MappingAdminAbstractView", "org/forgerock/commons/ui/common/main/Router", "org/forgerock/openidm/ui/admin/util/Scheduler", "org/forgerock/openidm/ui/admin/delegates/SchedulerDelegate", "org/forgerock/openidm/ui/admin/scheduler/SchedulerListView"], function ($, _, handlebars, ConfigDelegate, constants, eventManager, MappingAdminAbstractView, Router, Scheduler, SchedulerDelegate, SchedulerListView) {

    var ScheduleView = MappingAdminAbstractView.extend({
        template: "templates/admin/mapping/scheduling/SchedulerTemplate.html",
        element: "#schedulerView",
        noBaseTemplate: true,
        events: {
            "click #addNew": "addReconciliation"
        },
        model: {
            mapping: {}
        },
        partials: ["partials/scheduler/_ScheduleTypeDisplay.html"],

        render: function render(args, callback) {
            var _this = this;

            this.parentRender(function () {
                _this.model.mapping = _.omit(_this.getCurrentMapping(), "recon");

                SchedulerListView.buildGrid(_this.model.mapping.name).then(function (schedules) {
                    var noGrid = _this.$el.find("#schedulerGrid .empty");

                    if (schedules.result.length > 0 && !noGrid.length) {
                        _this.$el.find("#addNew").hide();
                        _this.$el.find(".schedule-input-body").show();
                    } else {
                        _this.$el.find("#scheduleList").hide();
                        _this.$el.find(".schedule-input-body").show();
                    }

                    if (callback) {
                        callback();
                    }
                });
            });
        },

        reconDeleted: function reconDeleted(id, name, element) {
            element.parent().find("#addNew").show();
            element.remove();
        },

        addReconciliation: function addReconciliation() {
            this.$el.find("#addNew").hide();
            eventManager.sendEvent(constants.ROUTE_REQUEST, { routeName: "addSchedulerView", args: [Router.getURIFragment()] });
        }
    });

    return new ScheduleView();
});
