"use strict";

/*
 * Copyright 2015-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["underscore", "org/forgerock/openidm/ui/admin/util/AdminAbstractView", "org/forgerock/openidm/ui/admin/workflow/ActiveProcessesView", "org/forgerock/openidm/ui/admin/workflow/ProcessDefinitionsView", "org/forgerock/openidm/ui/admin/workflow/ProcessHistoryView", "org/forgerock/commons/ui/common/main/AbstractCollection", "org/forgerock/commons/ui/common/util/Constants"], function (_, AdminAbstractView, ActiveProcessesView, ProcessDefinitionsView, ProcessHistoryView, AbstractCollection, Constants) {
    var ProcessListView = AdminAbstractView.extend({
        template: "templates/admin/workflow/ProcessListViewTemplate.html",
        events: {
            "change #processFilterType": "filterType"
        },
        model: {},
        render: function render(args, activeProcessCallback, processDefinitionsCallback, processHistoryCallback) {
            var processDefinition = {};

            this.parentRender(_.bind(function () {
                this.model.processDefinitions = new AbstractCollection();
                this.model.processDefinitions.url = Constants.context + "/workflow/processdefinition?_queryId=filtered-query";

                this.model.processDefinitions.getFirstPage().then(function (processDefinitions) {
                    processDefinition = _.chain(processDefinitions.result).map(function (pd) {
                        return _.pick(pd, "name", "key");
                    }).uniq(function (pdm) {
                        return pdm.name;
                    }).value();

                    ActiveProcessesView.render([processDefinition], activeProcessCallback);
                    ProcessDefinitionsView.render([], processDefinitionsCallback);
                    ProcessHistoryView.render([processDefinition], processHistoryCallback);
                });
            }, this));
        }
    });

    return new ProcessListView();
});
