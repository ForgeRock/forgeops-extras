"use strict";

/*
 * Copyright 2016-2026 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "org/forgerock/commons/ui/common/main/AbstractView"], function ($, AbstractView) {
    var ApiExplorerView = AbstractView.extend({
        template: "templates/admin/util/IframeViewTemplate.html",
        render: function render(args, callback) {
            this.data.iframeSrc = "/api/index.html";
            this.data.iframeClass = "api-explorer-iframe";
            this.parentRender(function () {
                var iframe = this.$el.find("." + this.data.iframeClass);

                iframe[0].style.height = iframe[0].contentWindow.document.body.scrollHeight + 'px';

                if (callback) {
                    callback();
                }
            });
        }
    });

    return new ApiExplorerView();
});
