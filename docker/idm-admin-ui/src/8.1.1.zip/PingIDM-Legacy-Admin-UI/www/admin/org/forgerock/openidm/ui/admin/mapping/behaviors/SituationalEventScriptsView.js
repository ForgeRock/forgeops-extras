"use strict";

/*
 * Copyright 2015-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["org/forgerock/openidm/ui/admin/mapping/util/MappingScriptsView"], function (MappingScriptsView) {
    var SituationalEventScriptsView = MappingScriptsView.extend({
        element: "#situationalQueries",
        noBaseTemplate: true,
        events: {
            "click .addScript": "addScript",
            "click .saveScripts": "saveScripts"
        },
        model: {
            scripts: ["onCreate", "onUpdate", "onDelete", "onLink", "onUnlink"],
            scriptEditors: {},
            successMessage: "triggeredBySituationSaveSuccess"
        },

        render: function render() {
            this.parentRender(function () {
                this.init();
            });
        }
    });

    return new SituationalEventScriptsView();
});
