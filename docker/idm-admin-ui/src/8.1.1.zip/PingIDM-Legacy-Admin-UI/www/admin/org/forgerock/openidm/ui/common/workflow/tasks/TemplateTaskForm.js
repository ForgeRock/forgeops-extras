"use strict";

/*
 * Copyright 2011-2025 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["handlebars", "org/forgerock/openidm/ui/common/workflow/tasks/AbstractTaskForm", "org/forgerock/commons/ui/common/util/DateUtil", "org/forgerock/commons/ui/common/main/Configuration"], function (Handlebars, AbstractTaskForm, DateUtil, conf, uiUtils) {

    var TemplateTaskForm = AbstractTaskForm.extend({

        template: "templates/common/EmptyTemplate.html",

        postRender: function postRender(callback) {
            var t = Handlebars.compile(this.args)(this.task);

            this.$el.html(t);

            if (callback) {
                callback();
            }
        }
    });

    return new TemplateTaskForm();
});
