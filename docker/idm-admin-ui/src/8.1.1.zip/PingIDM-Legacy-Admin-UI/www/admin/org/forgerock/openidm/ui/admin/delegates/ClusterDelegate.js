"use strict";

/*
 * Copyright 2015-2026 Ping Identity Corporation. All Rights Reserved
 *
 * This code is to be used exclusively in connection with Ping Identity
 * Corporation software or services. Ping Identity Corporation only offers
 * such software or services to legal entities who have entered into a
 * binding license agreement with Ping Identity Corporation.
 */

define(["jquery", "org/forgerock/commons/ui/common/util/Constants", "org/forgerock/commons/ui/common/main/AbstractDelegate"], function ($, Constants, AbstractDelegate) {

    var obj = new AbstractDelegate(Constants.host + Constants.context);

    obj.getNodes = function () {
        return obj.serviceCall({
            url: "/cluster?_queryFilter=true",
            type: "GET",
            suppressSpinner: true
        });
    };

    obj.getIndividualNode = function (nodeId) {
        return obj.serviceCall({
            url: "/cluster/" + nodeId,
            type: "GET",
            suppressSpinner: true
        });
    };

    return obj;
});
